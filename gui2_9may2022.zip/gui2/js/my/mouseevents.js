// $("#f-btn").mousedown(function(eventObj) {
//     $("#f-btn").mousemove(function(event) {
//       var pageCoords = "( " + event.pageX + ", " + event.pageY + " )";
//       var clientCoords = "( " + event.clientX + ", " + event.clientY + " )";
//       console.log(pageCoords, " : ", clientCoords);
//       // $("span:first").text("( event.pageX, event.pageY ) : " + pageCoords);
//       // $("span:last").text("( event.clientX, event.clientY ) : " + clientCoords);
//     });
// });
  
// $("#f-btn").mouseup(function(eventObj) {
//   console.log("unbinding");
//   $("#f-btn").unbind('mousemove');
// });