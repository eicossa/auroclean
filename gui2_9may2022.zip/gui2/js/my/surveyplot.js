async function drawSurveyPlot() {
    var elem = d3.select("#surveyplot").node();
    var w = Math.ceil(elem.getBoundingClientRect().width);
    var h = Math.ceil(elem.getBoundingClientRect().height);
    console.log(w)
    console.log(h)

    let dimensions = {
        width: w,
        height: h,
        margin: {
            top: 2,
            right: 2,
            bottom: 25,
            left: 2,
        },
    }

    dimensions.boundedWidth = dimensions.width
        - dimensions.margin.left
        - dimensions.margin.right

    dimensions.boundedHeight = dimensions.height
        - dimensions.margin.top
        - dimensions.margin.bottom


    const plot_wrapper = d3.select("#surveyplot")
        .append("svg")
            .attr("width", dimensions.width)
            .attr("height", dimensions.height)

    console.log(plot_wrapper)

    // the area where the actual drawing will take place
    const plot_bounds = plot_wrapper.append("g")
     .style("transform", `translate(${
        dimensions.margin.left
        }px, ${
        dimensions.margin.top
        }px)`)
     //.style("background-color", "#008000")
     //.attr("width", dimensions.boundedWidth)

    

    // when survey width or survey granularity changes
    d3.select("#cleaning_granularity").on("input", function () {
        update_granularity(+this.value);
        update_plot(plot_w, plot_g);
    })
    d3.select("#cleaningwidth").on("input", function() {
        update_width(+this.value);
        update_plot(plot_w, plot_g);
    })

    d3.select("#inc_gran").on("click", function() {
        let t = document.getElementById('cleaning_granularity');
        t.stepUp();
        update_granularity(t.value);
        update_plot(plot_w, plot_g);
    });
    d3.select("#dec_gran").on("click", function() {
        let t = document.getElementById('cleaning_granularity');
        t.stepDown();
        update_granularity(t.value);
        update_plot(plot_w, plot_g);
    });
    d3.select("#inc_width").on("click", function() {
        let t = document.getElementById('cleaningwidth');
        t.stepUp();
        update_width(t.value);
        update_plot(plot_w, plot_g);
    });
    d3.select("#dec_width").on("click", function() {
        let t = document.getElementById('cleaningwidth');
        t.stepDown();
        update_width(t.value);
        update_plot(plot_w, plot_g);
    });

    // d3-transition objects for all transitions
    // const exitTransition = d3.transition()
    //     .duration(600)

    // const updateTransition = exitTransition.transition()
    //     .duration(600)

    var data = [];
    var plot_w = 2;
    var plot_g = 0.4;
    update_granularity(plot_g);
    //d3.select("#cleaningwidth").property("step", plot_g);
    //d3.select("#cleaning_granularity").property("step", 1);
    update_width(plot_w);
    update_data(plot_w, plot_g);
    update_plot(plot_w, plot_g);

    plot_bounds.append("path")
        .attr("d", line(data))
        .attr("fill", "none")
        .attr("stroke", "#af3358")
        .attr("stroke-width", 2)

    // init static elements
    plot_bounds.append("g")
        .attr("class", "x-axis")
        .style("transform", `translateY(${dimensions.boundedHeight}px)`)
    .append("text")
        .attr("class", "x-axis-label")
        .attr("x", dimensions.boundedWidth / 2)
        .attr("y", dimensions.margin.bottom - 10)



    // update the elements
    function update_granularity(granularity) {
        plot_g = granularity;
        update_data(plot_w, plot_g);
        update_plot(plot_w, plot_g);
        // update_plot();

        // d3.select("#cleaningwidth").property("value", (plot_w));
        // d3.select("#cleaningwidth").property("step", plot_g);

        //d3.select("#cleaning_granularity")

        // adjust the text on the range slider
        d3.select("#cleaning_granularity-value").text(granularity);
        d3.select("#cleaning_granularity").property("value", granularity);
    }

    function update_width(width) {
        plot_w = width;
        update_data(plot_w, plot_g);
        update_plot(plot_w, plot_g);

        // adjust the text on the range slider
        d3.select("#cleaningwidth-value").text(width);
        d3.select("#cleaningwidth").property("value", width);
    }

    function update_data(w,g) {
        data = [];
        const length = 5;
        // to deal with the 0.1 decimal values allowed
        w = w*10;
        g = g*10;

        // refuse to generate data if not perfect divisor
        if(w%g != 0){
            data = [];
            return;
        }

        var nx = Math.ceil(w/g);
        var i,j;
        var m = 0;

        // if nx is odd
        for (i = 0; i <= nx-1; i+=2) {
            // start OR
            // go straight-down (from previous i)
            j = 0;
            data.push({x:i, y:j});

            // go straight-up
            j = 1;
            data.push({x:i, y:j});

            // turn-1
            data.push({x:i+1, y:j});

            // turn-2
            j = 0;
            data.push({x:i+1, y:j});
        }

        // if nx is even
        if(nx%2 === 0){
            // add an additional point to the right, turn and go up
            j = 0;
            data.push({x:i, y:j})
            j = 1;
            data.push({x:i, y:j})
        }
    }

    function update_plot(w,g) {

        var nsx1 = Math.ceil(w/g);

        walkX = d3.scaleLinear()
            .domain([0, nsx1]) // min-max
            .range([10, dimensions.width - 10]) // min-max
            .nice()

        walkY = d3.scaleLinear()
            .domain([0, 1]) // min-max
            .range([dimensions.boundedHeight - 10, 10]) // max-min

        line = d3.line()
            .x(p => walkX(p.x))
            .y(p => walkY(p.y))

        // draw axis
        const xAxisGenerator = d3.axisBottom()
             .scale(walkX)

        const xAxis = plot_bounds.select(".x-axis")
            .call(xAxisGenerator)

        const xAxisLabel = xAxis.select(".x-axis-label")
             .append("text")
             .attr("x", dimensions.boundedWidth/2)
             .attr("y", dimensions.margin.width - 10)
             .attr("fill", "black")
             .style("font-size", "1.4em")
             .html("turns")

        var tt = line(data)
        plot_bounds.select("path")
            .attr("d", tt)
    }

    
}

drawSurveyPlot()