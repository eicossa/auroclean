/* debugging */
var debug = true;
var debug2 = true;
var publishNow=false;

/* initialization stuff */

// initVelocityPublisher
var twist;
var cmdVel;

// initAutoMode
var bboolAuto;  
var isCleaningDone; 
var vector3; 
var cleaningPattern;
var pose0;
var clean
var restartMappingClient;
var restartMappingRequest;

// initCleaningPublisher()
var bbool; 
var cleanWithoutWater;
var cleanWithWater;
var stopCleaning;

// initTeleopKeyboard
var robotSpeedRange;
var teleop;

// window.onload function
var robot_IP;
var ros;

// survey dims
var lengthIn=document.getElementById("cleaninglength"); 
var widthIn=document.getElementById("cleaningwidth"); 
var shiftIn=document.getElementById("cleaning_granularity"); 
var l,w,g;

l = lengthIn.value;
w = widthIn.value;
g = shiftIn.value;

// cleaning elems
var cwwB=document.getElementById("water-clean-btn"); 
var cwowB=document.getElementById("nowater-clean-btn"); 
var scB=document.getElementById("stop-clean-btn"); 

// movements
var lb=document.getElementById("l-btn"); 
var rb=document.getElementById("r-btn"); 
var fb=document.getElementById("f-btn"); 
var bb=document.getElementById("b-btn"); 
var sb=document.getElementById("s-btn");

// speeds
var linSpeed=0.2;
var angSpeed=0.3; 
var lspeed = document.getElementById("linspeed-spnbox");
var aspeed = document.getElementById("angspeed-spnbox"); 

//----

function init_velocity_pub() {
  // Init message with zero values.
  twist = new ROSLIB.Message({
      linear: {
          x: 0,
          y: 0,
          z: 0
      },
      angular: {
          x: 0,
          y: 0,
          z: 0
      }
  }); 
  // Init topic object
  cmdVel = new ROSLIB.Topic({
      ros: ros,
      name: '/cmd_vel',
      messageType: 'geometry_msgs/Twist'
  });
  // Register publisher within ROS system
  cmdVel.advertise();
}

// ----

function init_auto_mode() {
  // Init Bool type 
  bboolAuto = new ROSLIB.Message({
      data: false  
  }); 

  // Init topic object
  isCleaningDone = new ROSLIB.Topic({
      ros: ros,
      name: '/isCleaningDone',
      messageType: 'std_msgs/Bool'
  }); 
  // Register publisher within ROS system
  isCleaningDone.advertise(); 


   // Init message with default values. (For Cleaning in Metres(x:CleaningLength, y: CleaningWidth, z: shift)) 
   vector3 = new ROSLIB.Message({
          x: 3.0,
          y: 1.6,
          z: 0.4  
  }); 
 
  // Init topic object
  cleaningPattern = new ROSLIB.Topic({ 
      ros: ros,
      name: '/cleaningPattern',
      messageType: 'geometry_msgs/Vector3' 
  }); 
  // Register publisher within ROS system
  cleaningPattern.advertise(); 

  pose0 = new ROSLIB.Message({
      position: {
          x: 0.0,
          y: 0.0,
          z: 0.0
      },
      orientation: { 
          x: 0.0,
          y: 0.0,
          z: 0.0, 
          w: 1.0
      }
  });
  restartMappingClient = new ROSLIB.Service({
      ros: ros,
      name: '/restart_mapping_with_new_pose',
      messageType: 'hector_mapping/ResetMapping' 
  });
  

  restartMappingRequest = new ROSLIB.ServiceRequest({
      initial_pose: pose0
  }); 
} 

// ----

function init_cleaning_pub() {
  // Init Bool type 
  bbool = new ROSLIB.Message({
      data: false  
  }); 

  // Init topic object
  cleanWithoutWater = new ROSLIB.Topic({
      ros: ros,
      name: '/startCleaningWithOutWater',
      messageType: 'std_msgs/Bool' 
  });
  // Register publisher within ROS system
  cleanWithoutWater.advertise(); 

  cleanWithWater = new ROSLIB.Topic({
      ros: ros,
      name: '/startCleaningWithWater',
      messageType: 'std_msgs/Bool'
  });
  // Register publisher within ROS system
  cleanWithWater.advertise(); 

  stopCleaning = new ROSLIB.Topic({
      ros: ros,
      name: '/stopCleaning',
      messageType: 'std_msgs/Bool' 
  });
  // Register publisher within ROS system
  stopCleaning.advertise(); 
  
}

// ----

function initTeleopKeyboard() {
  // Use w, s, a, d keys to drive your robot

  // Check if keyboard controller was aready created
  if (teleop == null) {
      // Initialize the teleop.
      teleop = new KEYBOARDTELEOP.Teleop({
          ros: ros,
          topic: '/cmd_vel'
      });
  }

  // Add event listener for slider moves
  robotSpeedRange = document.getElementById("robot-speed");
  robotSpeedRange.oninput = function () {
      teleop.scale = robotSpeedRange.value / 100
  }
}

// ----

window.onload = function () {
  // determine robot address automatically
  // robot_IP = location.hostname;
  // set robot address statically
  robot_IP = "localhost";

  // // Init handle for rosbridge_websocket
  ros = new ROSLIB.Ros({
    //   url: "ws://" + robot_IP + ":9090"
  });

  init_velocity_pub(); 
  init_cleaning_pub(); 
  init_auto_mode(); 

  // get handle for video placeholder
  //video = document.getElementById('video');
  // Populate video source 
  //video.src = "http://" + robot_IP + ":8080/stream?topic=/camera/rgb/image_raw&type=mjpeg&quality=80";
  /*video.onload = function () {
      // joystick and keyboard controls will be available only when video is correctly loaded
      createJoystick();
      initTeleopKeyboard();
  }; */ 

  //createJoystick();
  //initTeleopKeyboard(); 

}

// survey dims

function set_survey_dims() {
    l = lengthIn.value;
    w = widthIn.value;
    g = shiftIn.value;
    if(debug2) console.log("survey dims - l : ", l, " w : ", w, " g : ", g);
}

// cleaning stuff

function start_auto_mode() { 
    if(debug) console.log("start_auto_mode");
  try{
      vector3.x=parseFloat(l); 
      vector3.y=parseFloat(w); 
      vector3.z=parseFloat(g); 

      if(isNaN(vector3.x)||isNaN(vector3.y)||isNaN(vector3.z)) {
          console.log("NaaN Khalo"); 
          return; 
      }
      
      if(vector3.x<1||vector3.y<vector3.z||vector3.z<0.1) {
          return; 
      }
      cleaningPattern.publish(vector3);   
  }catch(err){ 
      console.log(err); 
      return; 
  }

  vector3.x=parseFloat(l); 
  vector3.y=parseFloat(w); 
  vector3.z=parseFloat(g); 

  cleaningPattern.publish(vector3);           

  bboolAuto.data=false; 
  isCleaningDone.publish(bboolAuto); 

  restartMappingClient.callService(restartMappingRequest,function(result) {
      console.log("ServiceCallResult: ",result); 
  }
  ); 
}

function clean_without_water() { 
    if(debug) console.log("clean_without_water()");
    bbool.data=true; 
    cleanWithoutWater.publish(bbool); 
}

function clean_with_water() { 
    if(debug) console.log("clean_with_water()");
    bbool.data=true; 
    cleanWithWater.publish(bbool); 
}

function cleaning_stop() { 
    if(debug) console.log("cleaning_stop()");
    bbool.data=true; 
    stopCleaning.publish(bbool); 
}

// speeds

function setSpeed() { 

    // lspeed.value=ss.value; 
    linSpeed = lspeed.value;
    angSpeed = aspeed.value;
    if(debug2) console.log("setSpeed with linSpeed : ", linSpeed, " angSpeed : ", angSpeed);
    
}

// manual controls 
var callcount = 0;
function moveAction(linear, angular) {
    callcount = callcount + 1;
    if (linear !== undefined && angular !== undefined) {
        twist.linear.x = linear;
        twist.angular.z = angular;
    } else {
        twist.linear.x = 0;
        twist.angular.z = 0;
    }
    if(debug2) console.log("moveAction call#",callcount, " with lspeed : ", linSpeed, " angspeed : ", angSpeed);
    cmdVel.publish(twist);
}

function setPublish(flag) 
{
    console.log("setting publishNow to : ", flag);
    publishNow = flag;
    console.log("setPublish : publishNow - ", publishNow);
}

function getPublish()
{
    return publishNow;
}

// movements


function mouseUP() { 
    moveAction(0,0);
    // setPublish(false);
    if(publishNow) {
        setPublish(false);
    }
    // publishNow=false; 
    // if(debug) console.log("mouseup", "publishNow : ", publishNow);
    // lb.style.backgroundColor='blue'; 
    // rb.style.backgroundColor='blue'; 
    // fb.style.backgroundColor='blue'; 
    // bb.style.backgroundColor='blue'; 
    // sb.style.backgroundColor='blue'; 
}

function mouseDownF() { 
    //xx.style.color=green; 
    // fb.style.backgroundColor='green'; 
    // publishNow=true; 
    setPublish(true);
    chaloSBBot(linSpeed*-1,angSpeed*0); 
    if(debug) console.log("f");
    // publishNow=false;
}

function mouseDownB() { 
    // bb.style.backgroundColor='green'; 
    // publishNow=true; 
    setPublish(true);
    chaloSBBot(linSpeed*+1,angSpeed*0); 
    if(debug) console.log("b");     
    // publishNow=false;
}

function mouseDownL() { 
    // lb.style.backgroundColor='green'; 
    // publishNow=true; 
    setPublish(true);
    chaloSBBot(linSpeed*0,angSpeed*+1); 
    if(debug) console.log("l");
    // publishNow=false;
}

function mouseDownR() { 
    // rb.style.backgroundColor='green'; 
    // publishNow=true; 
    setPublish(true);
    chaloSBBot(linSpeed*0,angSpeed*-1); 
    if(debug) console.log("r");
    // publishNow=false;
}

function mouseDownS() { 
    // sb.style.backgroundColor='red'; 
    // publishNow=true; 
    setPublish(true);
    chaloSBBot(linSpeed*0,angSpeed*0); 
    if(debug) console.log("s");
    // publishNow=false;
}

var callcount2 = 0;
function chaloSBBot(linSpeed,angSpeed) {
    // let b = getPublish();
    console.log("chaloSBbot call#",callcount2, "called with publishNow : ", publishNow);
    callcount2 = callcount2 + 1;
    if (publishNow===true) {
        moveAction(linSpeed,angSpeed);

        // could be replaced with a call to chaloSBBot
        // but that sends out too many events to 
        // moveAction
        // we use this setTimeout to rate-limit 
        setTimeout(function() {
            if(publishNow===true){
                chaloSBBot(linSpeed, angSpeed, publishNow);
            }
        }, 100);
        // chaloSBBot(linSpeed, angSpeed, publishNow);
    }



    // if (publishNow) {
    //     //publishNow = false;
    //     moveAction(linSpeed,angSpeed);  
    //     setTimeout(function () { 
    //         //publishNow = true; 
    //         // console.log("chaloSBbot called with publishNow : ", b);
    //         chaloSBBot(linSpeed,angSpeed,publishNow); 
    //         // b = getPublish();
    //     }, 100);
    // } 
    // else {
    //     console.log("chaloSBbot call#",callcount2, "called with publishNow : ", publishNow);
    // }
}

