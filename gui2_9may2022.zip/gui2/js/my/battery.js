var currentlevel = 0;
var batterylevels = [10,20,30,40,50,60,70,80,90,100];
var waterlevels = [100,90,80,70,60,50,40,30,20,10,0];


function changeBatteryLevel() {
    currentlevel++;
    if(currentlevel > 9) currentlevel = 0;
    // console.log(currentlevel);
    var b = batterylevels[currentlevel];
    var w = waterlevels[currentlevel];
    // console.log(b)

    d3.select("#batt-level")
    .style('width', `${b}%`)
    .text(b);

    d3.select("#wat-level")
    .style('width', `${w}%`)
    .text(w)

    // batteryLevel.css('width', level + '%');
// 	batteryLevel.text(level + '%');
    
}

setInterval(changeBatteryLevel, 1000);
