async function createEvent() {
    const rectColors = [
      "yellowgreen",
      "cornflowerblue",
      "seagreen",
      "slateblue",
    ]
  
    // create and bind data to our rects
    const lengthchanged = d3.select("#svg")
      .selectAll("#cleaninglength")
  
    // your code here
    lengthchanged
    .on("input_event", function(datum) {
      d3.select(this).style("stroke", "lightgrey")
    })

  
  }
  createEvent()

  function moveAction(linear, angular) {
    if (linear !== undefined && angular !== undefined) {
        twist.linear.x = linear;
        twist.angular.z = angular;
    } else {
        twist.linear.x = 0;
        twist.angular.z = 0;
    }
    cmdVel.publish(twist);
}


  function chaloSBBot(linSpeed,angSpeed) {


    if (publishNow) {
     //publishNow = false;
     moveAction(linSpeed,angSpeed);  
     setTimeout(function () { 
         //publishNow = true; 
         chaloSBBot(linSpeed,angSpeed); 
     }, 100);
     } 
    
 }


var rbutton = document.querySelector('#r-btn');
var lbutton = document.querySelector('#l-btn');
var fbutton = document.querySelector('#f-btn');
var bbutton = document.querySelector("#b-btn");
var sbutton = document.querySelector('#s-btn');
// const stopbtn = document.querySelector('#s-btn');
var controlbtn = document.querySelector('.manualcontrol');
controlbtn.addEventListener('click', update_movement);

lbutton.addEventListener('click', move_left);
rbutton.addEventListener('click', move_right);
fbutton.addEventListener('click', move_fwd);
bbutton.addEventListener('click', move_back);

function move_left() {
  publishNow=true; 
  // chaloSBBot(linSpeed*0,angSpeed*+1); 
}

function move_right() {
  publishNow=true;
  // chaloSBBot(linSpeed*0,angSpeed*-1); 
}

function move_fwd() {
  publishNow=true;
  // chaloSBBot(linSpeed*-1,angSpeed*0);
}

function move_back() {
  publishNow=true;
  // chaloSBBot(linSpeed*+1,angSpeed*0); 
}

function update_movement() {
  // console.log("update_movement()");
  // if(lbutton)
}

// function update_controls() {
//   console.log("update_controls");
//   if (controlbtn.id == 'r-btn') {
//     console.log("r-btn clicked");
//   }
// }

function increment_length() 
{
  document.getElementById('cleaninglength').stepUp();
}

function decrement_length() 
{
  document.getElementById('cleaninglength').stepDown();
}

function increment_width() 
{
  // document.getElementById('cleaningwidth').stepUp();
}

function decrement_width() 
{
  // document.getElementById('cleaningwidth').stepDown();
}

function increment_granularity() 
{
  // let ge = document.getElementById('cleaning_granularity').stepUp();
  // ge.dispatchEvent(new Event("input", { 'bubbles': true }));
}

function decrement_granularity() 
{
  // let ge = document.getElementById('cleaning_granularity').stepDown();
  // ge.dispatchEvent(new Event("input", { 'bubbles': true }));
}
